mod bitboard;
mod board;
mod eval;
mod movegen;
mod perft;
mod polyglot;
mod polyglot_random;
mod search;
mod see;
mod syzygy;
mod types;
mod zobrist;

use board::Board;
use search::Searcher;
use std::env;
use std::io::{self, BufRead, Write};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Instant;
use types::{Move, MoveFlag, PieceType};

const STARTPOS: &str = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
const KIWIPETE: &str = "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1";
const POSITION3: &str = "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1";
const POSITION5: &str = "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 0 1";

fn run_perft_suite() {
    let cases: Vec<(&str, &str, Vec<u64>)> = vec![
        ("posicion inicial", STARTPOS, vec![1, 20, 400, 8902, 197281, 4865609, 119060324]),
        ("kiwipete", KIWIPETE, vec![1, 48, 2039, 97862, 4085603, 193690690]),
        ("posicion 3", POSITION3, vec![1, 14, 191, 2812, 43238, 674624, 11030083]),
        ("posicion 5", POSITION5, vec![1, 44, 1486, 62379, 2103487, 89941194]),
    ];

    let mut todo_ok = true;
    for (nombre, fen, esperados) in &cases {
        let b = Board::from_fen(fen).expect("FEN invalido en suite de perft");
        println!("\n=== {} ===", nombre);
        for (depth, &esperado) in esperados.iter().enumerate() {
            let t0 = Instant::now();
            let n = perft::perft(&b, depth as u32);
            let dt = t0.elapsed();
            let ok = n == esperado;
            todo_ok &= ok;
            let nps = if dt.as_secs_f64() > 0.0 { n as f64 / dt.as_secs_f64() } else { 0.0 };
            println!(
                "  depth {}: {} (esperado {}) {}  [{:.2}s, {:.0} nps]",
                depth, n, esperado,
                if ok { "OK" } else { "*** FALLO ***" },
                dt.as_secs_f64(), nps
            );
            if !ok {
                break;
            }
        }
    }
    println!("\n{}", if todo_ok { "TODOS LOS PERFT OK" } else { "HAY FALLOS DE PERFT -- NO AVANZAR A FASE 3" });
}

fn run_divide(fen: &str, depth: u32) {
    let b = Board::from_fen(fen).expect("FEN invalido");
    let mut total = 0u64;
    for (uci, n) in perft::perft_divide(&b, depth) {
        println!("{}: {}", uci, n);
        total += n;
    }
    println!("total: {}", total);
}

fn run_smp_bench(movetime_ms: u64) {
    let fen = "r1bqk2r/ppp2ppp/2n2n2/2bpp3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 0 6";
    let b = Board::from_fen(fen).unwrap();
    println!("Benchmark Lazy SMP -- posicion de medio juego, {}ms por hilo/config", movetime_ms);
    for n in [1usize, 2, 4, 6, 8] {
        let (tt, tt_mask) = search::construir_tt(64);
        let t0 = Instant::now();
        let (mv, sc, nodos, resultados) = search::buscar_lazy_smp(
            &b, Some(movetime_ms), 64, n, &tt, tt_mask, false, &[], Arc::new(AtomicBool::new(false)),
        );
        let dt = t0.elapsed();
        let nps = nodos as f64 / dt.as_secs_f64().max(0.0001);
        let profs: Vec<i32> = resultados.iter().map(|r| r.profundidad).collect();
        println!(
            "  {} hilo(s): jugada={} score={} | {} nodos TOTALES en {:.2}s = {:.0} nps combinados | profundidades por hilo: {:?}",
            n, mv.map(|m| m.to_uci()).unwrap_or_default(), sc, nodos, dt.as_secs_f64(), nps, profs
        );
    }
}

fn run_bench(depth: i32) {
    let posiciones = [
        ("inicial", STARTPOS),
        ("medio juego", "r1bqk2r/ppp2ppp/2n2n2/2bpp3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 0 6"),
    ];
    for (nombre, fen) in posiciones {
        let b = Board::from_fen(fen).unwrap();
        let mut s = Searcher::new(64);
        let t0 = Instant::now();
        let (mv, sc, nodes) = s.search_fixed_depth(&b, depth);
        let dt = t0.elapsed();
        let nps = nodes as f64 / dt.as_secs_f64().max(0.0001);
        println!(
            "{}: profundidad {} -> {} (score {}) | {} nodos en {:.2}s = {:.0} nps",
            nombre, depth, mv.map(|m| m.to_uci()).unwrap_or_default(), sc, nodes, dt.as_secs_f64(), nps
        );
        if s.lmr_intentos > 0 {
            println!(
                "  LMR: {} intentos, {} re-busquedas a profundidad completa ({:.1}%)",
                s.lmr_intentos, s.lmr_reintentos, 100.0 * s.lmr_reintentos as f64 / s.lmr_intentos as f64
            );
        }
    }
}

fn run_lmr_diagnostico(depth: i32) {
    // Compara LMR encendido vs apagado en un lote de posiciones tacticas
    // conocidas, a PROFUNDIDAD FIJA (no por tiempo, para que la comparacion
    // sea limpia): si LMR encuentra el mismo score o mejor en todas, es
    // evidencia fuerte de que el mecanismo en si es correcto (no hay jugadas
    // tacticas que se esten perdiendo por la reduccion) y la perdida de ELO
    // medida en torneo es un tema de presupuesto de tiempo/profundidad
    // efectiva, no un bug de logica.
    let posiciones = [
        ("inicial", STARTPOS),
        ("medio juego", "r1bqk2r/ppp2ppp/2n2n2/2bpp3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 0 6"),
        ("tactica capturas", "r2q1rk1/pp1nbppp/2p1pn2/3p4/2PP4/1PN1PN2/PB3PPP/R2Q1RK1 w - - 0 10"),
        ("bug cxb4", "r1b1k2r/ppqp1ppp/4p3/4n3/1b6/2PQBN2/P1P2PPP/R3KB1R w KQkq - 0 11"),
        ("mate pastor", "r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4"),
        ("final torres", "8/5pk1/6p1/8/8/1R6/5PPP/6K1 w - - 0 1"),
        ("kiwipete-ish", "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"),
    ];
    let mut peor_encontrado = false;
    for (nombre, fen) in posiciones {
        let b = Board::from_fen(fen).unwrap();
        let mut s_sin = Searcher::new(32);
        s_sin.modo_lmr = false;
        let (mv_sin, sc_sin, _) = s_sin.search_fixed_depth(&b, depth);

        let mut s_con = Searcher::new(32);
        s_con.modo_lmr = true;
        let (mv_con, sc_con, _) = s_con.search_fixed_depth(&b, depth);

        let diff = sc_con - sc_sin;
        let peor = diff < -20; // margen chico de ruido por desempates de orden
        peor_encontrado |= peor;
        println!(
            "{:20} sin-LMR: {} (score {})   con-LMR: {} (score {})   diff={:+}  {}",
            nombre,
            mv_sin.map(|m| m.to_uci()).unwrap_or_default(), sc_sin,
            mv_con.map(|m| m.to_uci()).unwrap_or_default(), sc_con,
            diff,
            if peor { "*** LMR PEOR ***" } else if mv_sin == mv_con { "(misma jugada)" } else { "(distinta jugada, score similar)" }
        );
    }
    println!("\n{}", if peor_encontrado {
        "LMR encontro una jugada claramente peor en al menos una posicion -- revisar mas"
    } else {
        "LMR no perdio ninguna tactica en este lote a profundidad fija -- consistente con tradeoff de tiempo, no bug de logica"
    });
}

fn run_singular_diagnostico(depth: i32) {
    // Mismo protocolo que run_lmr_diagnostico (comparacion a profundidad FIJA,
    // no por tiempo): si singular extensions es correcto, el score CON
    // extensiones nunca deberia ser peor que SIN ellas en este lote -- una
    // jugada "singular" que en realidad no lo era, o un bug de contabilidad
    // de profundidad/ventana, se notaria como una caida de score o (mas
    // grave) una explosion de nodos sin límite claro. Verde en TODO este
    // lote es la condicion pedida antes de considerar activar el default.
    let posiciones = [
        ("inicial", STARTPOS),
        ("medio juego", "r1bqk2r/ppp2ppp/2n2n2/2bpp3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 0 6"),
        ("tactica capturas", "r2q1rk1/pp1nbppp/2p1pn2/3p4/2PP4/1PN1PN2/PB3PPP/R2Q1RK1 w - - 0 10"),
        ("bug cxb4", "r1b1k2r/ppqp1ppp/4p3/4n3/1b6/2PQBN2/P1P2PPP/R3KB1R w KQkq - 0 11"),
        ("mate pastor", "r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4"),
        ("final torres", "8/5pk1/6p1/8/8/1R6/5PPP/6K1 w - - 0 1"),
        ("kiwipete-ish", "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"),
        ("cacería de rey (partida real v11, jug.31)", "2r3k1/p1bQ1ppp/6b1/6N1/8/5P2/P4P1P/6K1 b - - 1 31"),
    ];
    let mut peor_encontrado = false;
    let mut nodos_explotaron = false;
    for (nombre, fen) in posiciones {
        let b = Board::from_fen(fen).unwrap();
        let mut s_sin = Searcher::new(32);
        s_sin.modo_singular = false;
        let (mv_sin, sc_sin, nodos_sin) = s_sin.search_fixed_depth(&b, depth);

        let mut s_con = Searcher::new(32);
        s_con.modo_singular = true;
        let (mv_con, sc_con, nodos_con) = s_con.search_fixed_depth(&b, depth);

        let diff = sc_con - sc_sin;
        let peor = diff < -20; // margen chico de ruido por desempates de orden
        let ratio_nodos = nodos_con as f64 / nodos_sin.max(1) as f64;
        let exploto = ratio_nodos > 4.0; // sondeos de SE suman busqueda extra, pero no deberian multiplicar por mucho mas que eso
        peor_encontrado |= peor;
        nodos_explotaron |= exploto;
        println!(
            "{:30} sin-SE: {} (score {}, {} nodos)   con-SE: {} (score {}, {} nodos, x{:.1})   diff={:+}  {}{}",
            nombre,
            mv_sin.map(|m| m.to_uci()).unwrap_or_default(), sc_sin, nodos_sin,
            mv_con.map(|m| m.to_uci()).unwrap_or_default(), sc_con, nodos_con, ratio_nodos,
            diff,
            if peor { "*** SE PEOR ***" } else if mv_sin == mv_con { "(misma jugada)" } else { "(distinta jugada, score similar)" },
            if exploto { "  *** EXPLOSION DE NODOS ***" } else { "" }
        );
    }
    println!("\n{}", if peor_encontrado || nodos_explotaron {
        "singular extensions FALLO el diagnostico -- NO activar por defecto (MIMOTOR_SINGULAR=1 sigue disponible solo para pruebas)"
    } else {
        "singular extensions paso el diagnostico: sin perdidas de score ni explosion de nodos en este lote"
    });
}

fn run_mate_tests() {
    let casos = [
        ("Mate en 1: Ta8# (pasillo)", "6k1/8/6K1/8/8/8/8/R7 w - - 0 1", "a1a8"),
        ("Mate en 1: Dh4# (mate del loco)", "rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq - 0 1", "d8h4"),
        ("Mate en 1: Dxf7# (mate pastor)", "r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4", "h5f7"),
    ];
    let mut todo_ok = true;
    for (nombre, fen, esperada) in casos.iter() {
        let b = Board::from_fen(fen).unwrap();
        let mut s = Searcher::new(16);
        let (mv, sc, nodes) = s.search_fixed_depth(&b, 4);
        let uci = mv.map(|m| m.to_uci()).unwrap_or_default();
        let ok = uci == *esperada;
        todo_ok &= ok;
        println!(
            "{} {} -> {} (esperada {}) score={} nodos={}",
            if ok { "OK  " } else { "FAIL" }, nombre, uci, esperada, sc, nodes
        );
    }
    println!("{}", if todo_ok { "TODOS LOS MATES OK" } else { "HAY FALLOS EN LA SUITE DE MATES" });
}

fn run_prueba_apertura() {
    // 1.e4 d5 2.exd5 Qxd5 -- el motor deberia enrocar en unas pocas jugadas
    // propias en vez de salir a cazar peones con la dama (bug historico de v1).
    let mut b = Board::from_fen(STARTPOS).unwrap();
    let mut s = Searcher::new(64);
    let jugadas_iniciales = ["e2e4", "d7d5", "e4d5", "d8d5"];
    for uci in jugadas_iniciales {
        b = aplicar_uci(&b, uci);
    }
    println!("Posicion tras 1.e4 d5 2.exd5 Qxd5, buscando 10 jugadas propias del motor...");
    let mut enrocó = false;
    for i in 0..10 {
        let (mv, sc, nodes) = s.search_fixed_depth(&b, 5);
        let mv = match mv {
            Some(m) => m,
            None => break,
        };
        println!("  jugada propia #{}: {} (score {}, {} nodos)", i + 1, mv.to_uci(), sc, nodes);
        if mv.flag == MoveFlag::CastleKing || mv.flag == MoveFlag::CastleQueen {
            enrocó = true;
        }
        b = b.make_move(&mv);
        if b.turn == types::Color::Black {
            // saltar la respuesta rival con una jugada legal cualquiera (la primera)
            let respuestas = movegen::generate_legal(&b);
            if let Some(r) = respuestas.first() {
                b = b.make_move(r);
            }
        }
        if enrocó {
            break;
        }
    }
    println!("{}", if enrocó { "OK: el motor enrocó" } else { "el motor NO enrocó en 10 jugadas" });
}

fn aplicar_uci(b: &Board, uci: &str) -> Board {
    let mv = parse_uci_move(b, uci).expect("jugada UCI invalida");
    b.make_move(&mv)
}

fn parse_uci_move(b: &Board, uci: &str) -> Option<Move> {
    let moves = movegen::generate_legal(b);
    let bytes = uci.as_bytes();
    if bytes.len() < 4 {
        return None;
    }
    let from = types::square_from_name(&uci[0..2])?;
    let to = types::square_from_name(&uci[2..4])?;
    let promo = if bytes.len() >= 5 { PieceType::from_char(bytes[4] as char) } else { None };
    moves.into_iter().find(|m| m.from == from && m.to == to && m.promotion == promo)
}

/// Construye una jugada SIN validar legalidad real de movimiento (solo
/// determina el flag -- Captura/AlPaso/Silenciosa -- a partir del estado
/// del tablero). Necesario para los casos sinteticos de test de SEE, donde
/// el "atacante inicial" puede estar bloqueado en la realidad (igual que
/// hace el test_see.py de Python, que tampoco valida legalidad del primer
/// movimiento -- SEE en si mismo confia en que el llamador ya eligio un
/// atacante valido).
fn jugada_sintetica(b: &Board, uci: &str) -> Move {
    let from = types::square_from_name(&uci[0..2]).unwrap();
    let to = types::square_from_name(&uci[2..4]).unwrap();
    let es_al_paso = b.piece_at(from).map(|(_, pt)| pt) == Some(PieceType::Pawn) && Some(to) == b.ep_square;
    let flag = if es_al_paso {
        MoveFlag::EnPassant
    } else if b.piece_at(to).is_some() {
        MoveFlag::Capture
    } else {
        MoveFlag::Quiet
    };
    Move::new(from, to, None, flag)
}

fn run_cxb4_bug() {
    let fen = "r1b1k2r/ppqp1ppp/4p3/4n3/1b6/2PQBN2/P1P2PPP/R3KB1R w KQkq - 0 11";
    let b = Board::from_fen(fen).unwrap();
    let mut s = Searcher::new(64);
    let (mv, sc, nodes) = s.search_fixed_depth(&b, 6);
    let uci = mv.map(|m| m.to_uci()).unwrap_or_default();
    println!("FEN bug cxb4: jugada elegida = {} (score {}, {} nodos)", uci, sc, nodes);
    println!("{}", if uci == "c3b4" { "eligio cxb4 (igual que v3 sin proteccion)" } else { "NO eligio cxb4" });
}

fn run_repetition_tests() {
    // Metodologia: buscar SIN contexto de repeticion para obtener la jugada
    // "natural" y la posicion que resulta de jugarla; despues sembrar
    // game_history con ESA posicion exacta (simulando que ya ocurrio una
    // vez antes en la partida) y volver a buscar. Esto prueba el mecanismo
    // de forma directa y verificable sin depender de armar a mano una
    // secuencia real de jaques repetibles.
    let mut ok = true;

    println!("=== Test A: GANANDO (K+D+T vs K), debe EVITAR repetir ===");
    // halfmove_clock=10 (no 0): la ventana de repeticion usa hc como
    // "cuantas jugadas reversibles hacia atras puedo mirar" -- con hc=0
    // es matematicamente imposible que exista una ocurrencia previa (el
    // contador se acaba de reiniciar), asi que hace falta margen real.
    let fen_a = "4k3/8/4K3/8/8/8/8/3QR3 w - - 10 6";
    let ba = Board::from_fen(fen_a).unwrap();
    let mut s1 = Searcher::new(16);
    let (mv1, sc1, _) = s1.search_fixed_depth(&ba, 6);
    let mv1 = mv1.expect("deberia haber jugada legal");
    let p2 = ba.make_move(&mv1);
    println!("  sin historial: jugada={} score={}", mv1.to_uci(), sc1);

    let mut s2 = Searcher::new(16);
    s2.set_game_history(vec![p2.zobrist]);
    let (mv2, sc2, _) = s2.search_fixed_depth(&ba, 6);
    let mv2 = mv2.expect("deberia haber jugada legal");
    println!("  con esa posicion ya \"vista\": jugada={} score={}", mv2.to_uci(), sc2);
    // Debe seguir siendo claramente ganador (no cerca de 0) -- si eligio la
    // MISMA jugada que antes, su resultado NO debe coincidir con p2 (busco
    // otra continuacion), o el score debe seguir siendo muy alto.
    let evito = mv2 != mv1 || sc2.abs() > 500;
    ok &= evito;
    println!("  {}", if evito { "OK: sigue jugando para ganar, no repite a lo tonto" } else { "FALLO: parece haber aceptado repetir estando ganando" });

    println!("\n=== Test B: PERDIENDO (K vs K+D+T), debe BUSCAR repetir ===");
    let fen_b = "8/8/4k3/8/8/4K3/8/3qr3 w - - 10 6";
    let bb = Board::from_fen(fen_b).unwrap();
    let mut s3 = Searcher::new(16);
    let (mv3, sc3, _) = s3.search_fixed_depth(&bb, 6);
    let mv3 = mv3.expect("deberia haber jugada legal");
    let p2b = bb.make_move(&mv3);
    println!("  sin historial: jugada={} score={} (posicion perdida de verdad)", mv3.to_uci(), sc3);

    let mut s4 = Searcher::new(16);
    s4.set_game_history(vec![p2b.zobrist]);
    let (mv4, sc4, _) = s4.search_fixed_depth(&bb, 6);
    let mv4 = mv4.expect("deberia haber jugada legal");
    println!("  con esa posicion ya \"vista\": jugada={} score={}", mv4.to_uci(), sc4);
    // Ahora debe preferir la tabla en vez de seguir perdiendo (sc3, que
    // deberia ser muy negativo o mate en contra). El "contempt" dinamico
    // (agregado en esta misma sesion) puntua la repeticion a +/-200 cuando
    // el eval esta claramente decidido, no exactamente 0 -- por eso el
    // margen es <= 200 (no < 200): el valor esperado de verdad es 200.
    let busca_tablas = sc4 > sc3 + 200 && sc4.abs() <= 200;
    ok &= busca_tablas;
    println!("  {}", if busca_tablas { "OK: prefiere la repeticion (tablas) en vez de seguir perdiendo" } else { "FALLO: no aprovecho la repeticion disponible" });

    println!("\n{}", if ok { "TODOS LOS TESTS DE REPETICION OK" } else { "HAY FALLOS EN LA DETECCION DE REPETICION" });
}

fn run_see_tests() {
    let mut ok = true;
    let casos: Vec<(&str, &str, &str, i32)> = vec![
        ("Caso 1 (captura libre)", "k7/8/8/7p/8/8/8/K6R w - - 0 1", "h1h5", 100),
        ("Caso 2 (1v1, mal cambio)", "k2r4/8/8/3p4/8/8/8/K2R4 w - - 0 1", "d1d5", 100 - 500),
        ("Caso 3 (2 atacantes vs 1 defensor)", "k2r4/8/8/3p4/8/8/3R4/K2R4 w - - 0 1", "d1d5", 100),
        ("Caso 4 (cxd5 con recaptura de peon)", "k7/8/4p3/3n4/2P5/1N6/8/K7 w - - 0 1", "c4d5", 220),
        ("Caso 5 (al paso, sin recaptura)", "k7/8/8/3pP3/8/8/8/K7 w - d6 0 1", "e5d6", 100),
        ("Caso 5b (al paso con recaptura)", "k7/2p5/8/3pP3/8/8/8/K7 w - d6 0 1", "e5d6", 0),
        ("Caso 6 (FEN del bug, cxb4)", "r1b1k2r/ppqp1ppp/4p3/4n3/1b6/2PQBN2/P1P2PPP/R3KB1R w KQkq - 0 11", "c3b4", 330),
    ];
    for (nombre, fen, uci, esperado) in &casos {
        let b = Board::from_fen(fen).unwrap();
        let mv = jugada_sintetica(&b, uci);
        let r = see::see(&b, &mv);
        let pass = r == *esperado;
        ok &= pass;
        println!("{} {}: see={} esperado={}", if pass { "OK  " } else { "FALLO" }, nombre, r, esperado);
    }
    println!("{}", if ok { "TODOS LOS CASOS DE SEE OK" } else { "HAY FALLOS EN SEE" });

    // Oraculo de fuerza bruta: posiciones al azar (self-play con jugadas
    // aleatorias desde la posicion inicial), comparando see() contra un
    // minimax real sobre TODAS las jugadas de captura posibles.
    println!("\nVerificando contra oraculo de fuerza bruta...");
    let mut rng_state: u64 = 0xC0FFEE1234567u64;
    let mut next_rand = move || {
        rng_state ^= rng_state << 13;
        rng_state ^= rng_state >> 7;
        rng_state ^= rng_state << 17;
        rng_state
    };

    let mut total_capturas = 0u64;
    let mut discrepancias = 0u64;
    for _partida in 0..5000 {
        let mut b = Board::startpos();
        let plies = 4 + (next_rand() % 20) as u32;
        let mut valida = true;
        for _ in 0..plies {
            let moves = movegen::generate_legal(&b);
            if moves.is_empty() {
                valida = false;
                break;
            }
            let mv = moves[(next_rand() as usize) % moves.len()];
            b = b.make_move(&mv);
        }
        if !valida {
            continue;
        }
        let capturas: Vec<Move> = movegen::generate_legal(&b).into_iter().filter(|m| m.is_capture()).collect();
        for mv in capturas {
            let rapido = see::see(&b, &mv);
            let oraculo = see::see_oracle(&b, &mv);
            total_capturas += 1;
            if rapido != oraculo {
                discrepancias += 1;
                println!(
                    "  DISCREPANCIA: fen='{}' jugada={} see={} oraculo={}",
                    b.to_fen(), mv.to_uci(), rapido, oraculo
                );
            }
        }
    }
    println!(
        "{} capturas comparadas, {} discrepancias -- {}",
        total_capturas, discrepancias,
        if discrepancias == 0 { "SEE COINCIDE CON EL ORACULO" } else { "HAY DISCREPANCIAS, revisar" }
    );
}

/// Handle de una busqueda corriendo en su propio hilo (spawneada al recibir
/// "go") + la bandera compartida para pedirle que pare ("stop"). El hilo
/// devuelve el Searcher de un solo hilo si lo tomo prestado (para
/// recuperarlo y seguir usandolo en la siguiente jugada), o None si la
/// busqueda fue Lazy SMP (esos Searchers son desechables, no hay uno
/// persistente que recuperar -- solo la TT compartida, que vive aparte).
struct BusquedaActiva {
    handle: std::thread::JoinHandle<Option<Searcher>>,
    stop_flag: Arc<AtomicBool>,
}

/// Si hay una busqueda en curso, le pide que pare y espera a que termine
/// (casi instantaneo: el hilo de busqueda revisa la bandera cada 1024 nodos)
/// para recuperar el Searcher de un solo hilo, si corresponde. Se llama
/// defensivamente antes de procesar cualquier comando UCI que no sea
/// "isready" -- un GUI que cumple el protocolo siempre manda "stop" antes de
/// "position"/"go"/"ucinewgame" nuevos, pero esto evita un panic si alguno
/// no lo hace.
fn detener_y_recuperar(activa: &mut Option<BusquedaActiva>, searcher_slot: &mut Option<Searcher>) {
    if let Some(a) = activa.take() {
        a.stop_flag.store(true, Ordering::Relaxed);
        if let Ok(Some(s)) = a.handle.join() {
            *searcher_slot = Some(s);
        }
    }
}

fn uci_loop() {
    let stdin = io::stdin();
    let mut board = Board::from_fen(STARTPOS).unwrap();
    let mut tt_mb: usize = 64;
    let mut searcher_slot: Option<Searcher> = Some(Searcher::new(tt_mb));
    let mut game_history: Vec<u64> = Vec::new();
    // MIMOTOR_HILOS sigue funcionando como default de conveniencia para
    // pruebas locales, pero un tester UCI (CCRL y similares) SOLO configura
    // motores por "setoption", nunca por variables de entorno -- por eso
    // "Threads" tambien es una opcion UCI real (ver abajo) que sobreescribe
    // este valor inicial.
    let mut n_hilos: usize = std::env::var("MIMOTOR_HILOS").ok().and_then(|s| s.parse().ok()).unwrap_or(1);
    if let Ok(p) = std::env::var("MIMOTOR_PERSONALIDAD") {
        if let Some(pers) = eval::personalidad_desde_texto(&p) {
            eval::set_personalidad(pers);
        }
    }
    if let Ok(path) = std::env::var("MIMOTOR_SYZYGY_PATH") {
        match syzygy::init(&path) {
            Ok(max) => eprintln!("info string tablas Syzygy cargadas ({} piezas max)", max),
            Err(e) => eprintln!("info string error cargando tablas Syzygy: {}", e),
        }
    }
    if let Ok(path) = std::env::var("MIMOTOR_BOOK_PATH") {
        match polyglot::init(&path) {
            Ok(n) => eprintln!("info string libro de aperturas cargado ({} entradas)", n),
            Err(e) => eprintln!("info string error cargando libro de aperturas: {}", e),
        }
    }
    let usar_libro_inicial: bool = std::env::var("MIMOTOR_SIN_LIBRO").as_deref() != Ok("1");
    polyglot::set_activo(usar_libro_inicial);
    // TT compartida persistente para Lazy SMP -- se construye una sola vez y
    // se reutiliza entre jugadas de la partida (igual que la TT normal de
    // un Searcher), no se reconstruye en cada "go".
    let (mut smp_tt, mut smp_tt_mask) = search::construir_tt(tt_mb);
    let mut activa: Option<BusquedaActiva> = None;

    for line in stdin.lock().lines() {
        let line = match line {
            Ok(l) => l,
            Err(_) => break,
        };
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let partes: Vec<&str> = line.split_whitespace().collect();

        // "stop" y "isready" se manejan aparte (no deben esperar a que se
        // libere una busqueda en curso). Todo lo demas primero se asegura de
        // que no haya una busqueda activa antes de tocar board/searcher.
        if partes[0] == "stop" {
            detener_y_recuperar(&mut activa, &mut searcher_slot);
            continue;
        }
        if partes[0] == "isready" {
            println!("readyok");
            io::stdout().flush().ok();
            continue;
        }
        detener_y_recuperar(&mut activa, &mut searcher_slot);

        match partes[0] {
            "uci" => {
                println!("id name MiMotor Tal v13 (Rust)");
                println!("id author Tavito y Claude");
                println!("option name Hash type spin default 64 min 1 max 1024");
                println!("option name Threads type spin default {} min 1 max 16", n_hilos);
                println!("option name Personalidad type combo default tal var tal var universal");
                println!("option name SyzygyPath type string default <empty>");
                println!("option name BookPath type string default <empty>");
                println!("option name OwnBook type check default true");
                println!("uciok");
                io::stdout().flush().ok();
            }
            "setoption" => {
                if let Some(ni) = partes.iter().position(|&p| p == "name") {
                    let nombre = partes.get(ni + 1).copied().unwrap_or("");
                    let vi = partes.iter().position(|&p| p == "value");
                    let valor = vi.and_then(|j| partes.get(j + 1)).copied();
                    if nombre.eq_ignore_ascii_case("personalidad") {
                        if let Some(valor) = valor {
                            if let Some(pers) = eval::personalidad_desde_texto(valor) {
                                eval::set_personalidad(pers);
                            } else {
                                println!("info string valor de Personalidad invalido: {}", valor);
                            }
                        }
                    } else if nombre.eq_ignore_ascii_case("hash") {
                        if let Some(mb) = valor.and_then(|v| v.parse::<usize>().ok()) {
                            // El nuevo tamano se aplica recien en el proximo
                            // "ucinewgame" (igual que la mayoria de los motores
                            // UCI: cambiar el tamano de una TT compartida a
                            // mitad de partida no es seguro ni tiene sentido).
                            tt_mb = mb.clamp(1, 1024);
                        }
                    } else if nombre.eq_ignore_ascii_case("threads") {
                        if let Some(n) = valor.and_then(|v| v.parse::<usize>().ok()) {
                            n_hilos = n.clamp(1, 16);
                        }
                    } else if nombre.eq_ignore_ascii_case("syzygypath") {
                        if let Some(path) = valor {
                            match syzygy::init(path) {
                                Ok(max) => println!("info string tablas Syzygy cargadas ({} piezas max)", max),
                                Err(e) => println!("info string error cargando tablas Syzygy: {}", e),
                            }
                        }
                    } else if nombre.eq_ignore_ascii_case("bookpath") {
                        if let Some(path) = valor {
                            match polyglot::init(path) {
                                Ok(n) => println!("info string libro de aperturas cargado ({} entradas)", n),
                                Err(e) => println!("info string error cargando libro de aperturas: {}", e),
                            }
                        }
                    } else if nombre.eq_ignore_ascii_case("ownbook") {
                        if let Some(v) = valor {
                            polyglot::set_activo(v.eq_ignore_ascii_case("true"));
                        }
                    }
                }
                io::stdout().flush().ok();
            }
            "ucinewgame" => {
                board = Board::from_fen(STARTPOS).unwrap();
                game_history.clear();
                searcher_slot = Some(Searcher::new(tt_mb));
                let (nueva_tt, nueva_mask) = search::construir_tt(tt_mb);
                smp_tt = nueva_tt;
                smp_tt_mask = nueva_mask;
            }
            "position" => {
                let mut idx = 1;
                if partes.get(1) == Some(&"startpos") {
                    board = Board::from_fen(STARTPOS).unwrap();
                    idx = 2;
                } else if partes.get(1) == Some(&"fen") {
                    let moves_pos = partes.iter().position(|&p| p == "moves").unwrap_or(partes.len());
                    let fen = partes[2..moves_pos].join(" ");
                    board = match Board::from_fen(&fen) {
                        Ok(b) => b,
                        Err(e) => {
                            println!("info string error de FEN: {}", e);
                            continue;
                        }
                    };
                    idx = moves_pos;
                }
                // Historial de claves Zobrist de la partida real (para deteccion
                // de repeticion) -- clave de CADA posicion ancestro, sin incluir
                // la posicion final/actual (esa la maneja negamax directamente).
                game_history.clear();
                if partes.get(idx) == Some(&"moves") {
                    for uci in &partes[idx + 1..] {
                        if let Some(mv) = parse_uci_move(&board, uci) {
                            game_history.push(board.zobrist);
                            board = board.make_move(&mv);
                        }
                    }
                }
            }
            "go" => {
                let infinito = partes.iter().any(|&p| p == "infinite");
                if let Some(i) = partes.iter().position(|&p| p == "depth") {
                    let depth: i32 = partes.get(i + 1).and_then(|s| s.parse().ok()).unwrap_or(6);
                    let mut s = searcher_slot.take().unwrap();
                    s.set_game_history(game_history.clone());
                    let stop_flag = Arc::new(AtomicBool::new(false));
                    s.set_external_stop(Some(Arc::clone(&stop_flag)));
                    let board_copy = board;
                    let handle = std::thread::spawn(move || {
                        let (mv, sc, _) = s.search_fixed_depth(&board_copy, depth);
                        println!("info score cp {}", sc);
                        println!("bestmove {}", mv.map(|m| m.to_uci()).unwrap_or_else(|| "0000".to_string()));
                        io::stdout().flush().ok();
                        Some(s)
                    });
                    activa = Some(BusquedaActiva { handle, stop_flag });
                    continue;
                }

                // movetime explicito, o wtime/btime(+winc/binc/movestogo), o
                // "go infinite" (sin limite propio, corta solo con "stop").
                let mut movetime: Option<u64> = None;
                if let Some(i) = partes.iter().position(|&p| p == "movetime") {
                    movetime = partes.get(i + 1).and_then(|s| s.parse().ok());
                } else if !infinito {
                    if let Some(i) = partes.iter().position(|&p| p == "wtime") {
                        let wtime: i64 = partes.get(i + 1).and_then(|s| s.parse().ok()).unwrap_or(10000);
                        let btime_i = partes.iter().position(|&p| p == "btime");
                        let btime: i64 = btime_i.and_then(|j| partes.get(j + 1)).and_then(|s| s.parse().ok()).unwrap_or(10000);
                        let winc: i64 = partes.iter().position(|&p| p == "winc")
                            .and_then(|j| partes.get(j + 1)).and_then(|s| s.parse().ok()).unwrap_or(0);
                        let binc: i64 = partes.iter().position(|&p| p == "binc")
                            .and_then(|j| partes.get(j + 1)).and_then(|s| s.parse().ok()).unwrap_or(0);
                        let movestogo: i64 = partes.iter().position(|&p| p == "movestogo")
                            .and_then(|j| partes.get(j + 1)).and_then(|s| s.parse().ok()).unwrap_or(30);
                        let (mio, inc) = if board.turn == types::Color::White { (wtime, winc) } else { (btime, binc) };
                        // Reparto clasico: tiempo restante / jugadas que quedan
                        // hasta el proximo control, mas la mayor parte del
                        // incremento (dejando margen para no pasarse de largo).
                        // Techo ADAPTATIVO (no uno solo fijo): el techo bajo
                        // (3.5s) que hubo antes se puso para relojes de
                        // CORRESPONDENCIA (base de dias, llega como wtime en
                        // ms -- sin tope, la formula salia en horas reales,
                        // medido en partidas reales). Pero aplicado siempre
                        // tambien capaba blitz/rapid/clasica -- en el
                        // config.yml del bot, max_base de partidas normales
                        // es 1800s (30 min), asi que cualquier wtime bien por
                        // encima de eso (>40 min) es casi con certeza
                        // correspondencia, no una partida real de tiempo
                        // rapido/clasico -- ahi si aplica el techo estricto.
                        // Con tiempo real (rapid/clasica largas), un techo de
                        // 20s deja pensar mucho mas sin arriesgar el reloj
                        // (20s todavia es una fraccion chica de 10-30 min).
                        const UMBRAL_CORRESPONDENCIA_MS: i64 = 40 * 60 * 1000;
                        let techo: u64 = if mio > UMBRAL_CORRESPONDENCIA_MS { 3_500 } else { 20_000 };
                        let base = mio / movestogo.max(1);
                        movetime = Some(((base + inc * 8 / 10).max(50) as u64).min(techo));
                    } else {
                        movetime = Some(2000); // "go" sin ningun parametro de tiempo: default razonable
                    }
                }

                let stop_flag = Arc::new(AtomicBool::new(false));
                let board_copy = board;
                let hist_copy = game_history.clone();

                if n_hilos > 1 {
                    let modo_lmr = searcher_slot.as_ref().unwrap().modo_lmr;
                    let tt = Arc::clone(&smp_tt);
                    let mask = smp_tt_mask;
                    let flag = Arc::clone(&stop_flag);
                    let handle = std::thread::spawn(move || {
                        let (mv, sc, nodos, _) = search::buscar_lazy_smp(
                            &board_copy, movetime, 64, n_hilos, &tt, mask, modo_lmr, &hist_copy, flag,
                        );
                        println!("info score cp {} nodes {}", sc, nodos);
                        println!("bestmove {}", mv.map(|m| m.to_uci()).unwrap_or_else(|| "0000".to_string()));
                        io::stdout().flush().ok();
                        None
                    });
                    activa = Some(BusquedaActiva { handle, stop_flag });
                } else {
                    let mut s = searcher_slot.take().unwrap();
                    s.set_game_history(hist_copy);
                    s.set_external_stop(Some(Arc::clone(&stop_flag)));
                    let handle = std::thread::spawn(move || {
                        let (mv, _sc, _) = s.search_time(&board_copy, movetime, 64, |depth, score, nodes, ms| {
                            println!("info depth {} score cp {} nodes {} time {}", depth, score, nodes, ms);
                            io::stdout().flush().ok();
                        });
                        println!("bestmove {}", mv.map(|m| m.to_uci()).unwrap_or_else(|| "0000".to_string()));
                        io::stdout().flush().ok();
                        Some(s)
                    });
                    activa = Some(BusquedaActiva { handle, stop_flag });
                }
            }
            "quit" => {
                detener_y_recuperar(&mut activa, &mut searcher_slot);
                break;
            }
            _ => {}
        }
    }
}


fn run_simple(fen: &str, movetime_ms: u64) {
    let b = match Board::from_fen(fen) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("FEN invalido: {}", e);
            return;
        }
    };

    let mut s = Searcher::new(64);
    let (mv, sc, depth) = s.search_time(&b, Some(movetime_ms), 64, |_, _, _, _| {});
    println!("================ MiMotor Tal V13 ================");
    println!("Mejor jugada: {}", mv.map(|m| m.to_uci()).unwrap_or_else(|| "0000".to_string()));
    println!("Evaluacion: {:+.2}", sc as f64 / 100.0);
    println!("Profundidad: {}", depth);
    println!("Nodos: {}", s.nodes);
    println!("==================================================");
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() > 1 {
        match args[1].as_str() {
            "simple" if args.len() >= 3 => {
                // Uso:
                //   mimotor-tal-rust simple "FEN"
                //   mimotor-tal-rust simple 3000 "FEN"
                let (movetime, fen_inicio) = match args.get(2).and_then(|s| s.parse::<u64>().ok()) {
                    Some(ms) if args.len() >= 4 => (ms, 3usize),
                    _ => (2000u64, 2usize),
                };
                let fen = args[fen_inicio..].join(" ");
                run_simple(&fen, movetime);
                return;
            }
            "perft" => {
                run_perft_suite();
                return;
            }
            "divide" if args.len() > 3 => {
                let depth: u32 = args[2].parse().expect("profundidad invalida");
                let fen = args[3..].join(" ");
                run_divide(&fen, depth);
                return;
            }
            "bench" => {
                let depth: i32 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(6);
                run_bench(depth);
                return;
            }
            "matetest" => {
                run_mate_tests();
                return;
            }
            "aperturatest" => {
                run_prueba_apertura();
                return;
            }
            "cxb4test" => {
                run_cxb4_bug();
                return;
            }
            "seetest" => {
                run_see_tests();
                return;
            }
            "repetitiontest" => {
                run_repetition_tests();
                return;
            }
            "lmrdiag" => {
                let depth: i32 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(9);
                run_lmr_diagnostico(depth);
                return;
            }
            "singulartest" => {
                let depth: i32 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(9);
                run_singular_diagnostico(depth);
                return;
            }
            "smpbench" => {
                let movetime: u64 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(2000);
                run_smp_bench(movetime);
                return;
            }
            _ => {}
        }
    }
    uci_loop();
}
